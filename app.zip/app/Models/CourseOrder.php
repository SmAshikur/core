<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CourseOrder extends Model
{
    protected $table = "course_orders";
    
    protected $guarded = ['id'];
    
    public $timestamps = true;
}