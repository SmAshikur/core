<div class="js-cookie-consent cookie-consent">

    <div class="container">
        <div class="cookie-container">
          <span class="cookie-consent__message">
            <?php echo e($setting->cookie_text); ?>

          </span>

          <button class="btn btn-info js-cookie-consent-agree cookie-consent__agree">
              <?php echo e(__('Allow Cookies')); ?>

          </button>
        </div>
      </div>

</div>
<?php /**PATH /home3/therapylabonline/public_html/core/resources/views/vendor/cookieConsent/dialogContents.blade.php ENDPATH**/ ?>